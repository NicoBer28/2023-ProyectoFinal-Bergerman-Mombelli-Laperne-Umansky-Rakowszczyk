package com.example.proyectofinal.Activities

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import com.example.proyectofinal.Fragments.*
import com.example.proyectofinal.R
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*

lateinit var btnPublicar: Button

lateinit var vendedorHorarioRetiro: EditText
lateinit var vendedorPrecio : EditText
lateinit var vendedorProducto: EditText
lateinit var vendedorFechaMaximaConsumo: EditText

lateinit var vendedorHorarioRetiroIngresada : String
lateinit var vendedorPrecioIngresado : String
lateinit var vendedorProductoIngresado : String
lateinit var vendedorFechaMaximaConsumoIngresado : String

var camposVacios: Int = 0

class ativityVendedores : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity__vendedores) // Aquí debes especificar el diseño de tu actividad

        val db = Firebase.firestore

        auth = Firebase.auth

        val idUsuarioActual = Firebase.auth.currentUser?.uid
        Log.d("MiApp", "Valor de idUsuarioActual: $idUsuarioActual")

        btnPublicar = findViewById<Button>(R.id.btnPublicar)

        vendedorHorarioRetiro = findViewById<EditText>(R.id.direccionV)
        vendedorPrecio = findViewById<EditText>(R.id.passwordCreateV)
        vendedorProducto = findViewById<EditText>(R.id.passwordConfirmV)
        vendedorFechaMaximaConsumo = findViewById<EditText>(R.id.fechaMaxima)

        btnPublicar.setOnClickListener {
            vendedorHorarioRetiroIngresada = vendedorHorarioRetiro.text.toString()
            vendedorPrecioIngresado = vendedorPrecio.text.toString()
            vendedorProductoIngresado = vendedorProducto.text.toString()
            vendedorFechaMaximaConsumoIngresado = vendedorFechaMaximaConsumo.text.toString()

            var usuarios: MutableList<String> = mutableListOf(
                vendedorHorarioRetiroIngresada,
                vendedorPrecioIngresado,
                vendedorProductoIngresado,
                vendedorFechaMaximaConsumoIngresado
            )
            camposVacios = 0

            for (campos in usuarios) {
                if (campos == "") {
                    camposVacios = 1
                    val snackbar =
                        Snackbar.make(it, "Complete todos los campos", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                }
            }

            if (camposVacios == 0) {
                val snackbar =
                    Snackbar.make(it, "Publicacion Creada", Snackbar.LENGTH_SHORT)
                snackbar.show()

                val userActual = FirebaseAuth.getInstance().currentUser

                // Genera un ID único y aleatorio
                val nuevoID = UUID.randomUUID().toString()

                // Crea una referencia al documento con el nuevo ID en la colección "publicaciones"
                val userDocRef = db.collection("publicaciones").document(nuevoID)

                // Set the data for the user document
                val userData = hashMapOf(
                    "Id vendedor" to idUsuarioActual,
                    "Horario De Retiro" to vendedorHorarioRetiroIngresada,
                    "Precio" to vendedorPrecioIngresado,
                    "Producto" to vendedorProductoIngresado,
                    "Fecha Maxima Consumo" to vendedorFechaMaximaConsumoIngresado
                )

                userDocRef.set(userData).addOnSuccessListener {

                }.addOnFailureListener { e ->
                    val snackbar = Snackbar.make(it, "Error subiendo la publicacion", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                }

            }
        }
    }
}

