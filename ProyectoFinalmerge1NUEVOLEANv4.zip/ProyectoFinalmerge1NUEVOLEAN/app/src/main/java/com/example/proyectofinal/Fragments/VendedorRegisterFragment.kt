package com.example.proyectofinal.Fragments

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.navigation.fragment.findNavController
import com.example.proyectofinal.R
import com.example.proyectofinal.ViewModelsFragments.VendedorRegisterViewModel
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

lateinit var vendedorNegocio: EditText
lateinit var vendedorEmail: EditText
lateinit var vendedorDireccion: EditText
lateinit var vendedorPassword : EditText
lateinit var vendedorPasswordConfirm: EditText

lateinit var btnFragmentRegister: Button
lateinit var btnConfirmRegister: Button

lateinit var vendedorNegocioIngresado : String
lateinit var vendedorEmailIngresado : String
lateinit var vendedorDireccionIngresada : String
lateinit var vendedorContraIngresada : String
lateinit var vendedorContraConfIngresada : String

var camposVacios: Int = 0


class vendedorRegisterFragment : Fragment() {
    private lateinit var auth: FirebaseAuth

    companion object {
        fun newInstance() = vendedorRegisterFragment()
    }

    private lateinit var viewModel: VendedorRegisterViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_vendedor_register, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val db = Firebase.firestore

        auth = Firebase.auth

        btnFragmentRegister = view.findViewById<Button>(R.id.btnPreviousFragmentV)
        btnConfirmRegister = view.findViewById<Button>(R.id.registerConfirmV)
        vendedorNegocio = view.findViewById<EditText>(R.id.negocioV)
        vendedorEmail = view.findViewById<EditText>(R.id.emailV)
        vendedorDireccion = view.findViewById<EditText>(R.id.direccionV)
        vendedorPassword = view.findViewById<EditText>(R.id.passwordCreateV)
        vendedorPasswordConfirm = view.findViewById<EditText>(R.id.passwordConfirmV)

        btnConfirmRegister.setOnClickListener {
            vendedorNegocioIngresado = vendedorNegocio.text.toString()
            vendedorEmailIngresado = vendedorEmail.text.toString()
            vendedorDireccionIngresada = vendedorDireccion.text.toString()
            vendedorContraIngresada = vendedorPassword.text.toString()
            vendedorContraConfIngresada = vendedorPasswordConfirm.text.toString()

            var usuarios: MutableList<String> = mutableListOf(vendedorNegocioIngresado,
                vendedorEmailIngresado,
                vendedorDireccionIngresada,
                vendedorContraIngresada,
                vendedorContraConfIngresada)

            for(campos in usuarios){
                if(campos == ""){
                    camposVacios = 1
                }
            }

            if(vendedorContraIngresada == vendedorContraConfIngresada && camposVacios == 0) {


                auth.createUserWithEmailAndPassword(vendedorEmailIngresado, vendedorContraIngresada)
                    .addOnCompleteListener() { task ->
                        if (task.isSuccessful) {
                            // Get the currently authenticated user
                            val userActual = FirebaseAuth.getInstance().currentUser

                            // Create a new user document with the user's ID as the document ID
                            val userDocRef = userActual?.let { it1 ->
                                db.collection("vendedores").document(
                                    it1.uid
                                )
                            }

                            // Set the data for the user document
                            val userData = hashMapOf(
                                "Negocio" to vendedorNegocioIngresado,
                                "Email" to vendedorEmailIngresado,
                                "Direccion" to vendedorDireccionIngresada,
                                "Contraseña" to vendedorContraIngresada
                            )

                            userDocRef?.set(userData)?.addOnSuccessListener {

                            }?.addOnFailureListener { e ->
                                val snackbar =
                                    Snackbar.make(it, "usuario creado", Snackbar.LENGTH_SHORT)
                                snackbar.show()
                            }

                            val snackbar =
                                Snackbar.make(it, "usuario creado", Snackbar.LENGTH_SHORT)
                            snackbar.show()

                            findNavController().navigate(R.id.ativityVendedores)

                        } else {
                            // If sign in fails, display a message to the user.

                            val snackbar = Snackbar.make(it, "La contraseña debe contener al menos 6 caracteres", Snackbar.LENGTH_SHORT)
                            snackbar.show()
                        }
                    }
            }else {
                if (camposVacios == 1) {
                    camposVacios = 0
                    val snackbar =
                        Snackbar.make(it, "Hay campos vacios", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                } else {
                    val snackbar =
                        Snackbar.make(it, "Las contraseñas no coinciden", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                }
            }
        }

        btnFragmentRegister.setOnClickListener {
            findNavController().navigate(R.id.register_fragment)
        }
    }


}