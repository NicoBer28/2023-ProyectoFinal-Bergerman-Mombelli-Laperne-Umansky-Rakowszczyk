package com.example.proyectofinal;

public class item {

    String local3;
    String direccion3;
    String distancia3;
    String horario3;
    String precio3;
    String producto3;
    String reserva3;
    String confirmacion2;
    String id3;
    String caducidad3;


    public String getCaducidad3() {
        return caducidad3;
    }

    public void setCaducidad3(String caducidad3) {
        this.caducidad3 = caducidad3;
    }


    public String getLocal3() {
        return local3;
    }

    public void setLocal3(String local3) {
        this.local3 = local3;
    }

    public String getDireccion3() {
        return direccion3;
    }

    public void setDireccion3(String direccion3) {
        this.direccion3 = direccion3;
    }

    public String getDistancia3() {
        return distancia3;
    }

    public void setDistancia3(String distancia3) {
        this.distancia3 = distancia3;
    }

    public String getHorario3() {
        return horario3;
    }

    public void setHorario3(String horario3) {
        this.horario3 = horario3;
    }

    public String getPrecio3() {
        return precio3;
    }

    public void setPrecio3(String precio3) {
        this.precio3 = precio3;
    }

    public String getProducto3() {
        return producto3;
    }

    public void setReserva3(String reserva3) {
        this.reserva3 = reserva3;
    }

    public String getReserva3() {
        return reserva3;
    }

    public void setProducto3(String producto3) {
        this.producto3 = producto3;
    }
    public String getId3() {
        return id3;
    }

    public void setId3(String id3) {
        this.id3 = id3;
    }

    public void setConfirmacion2(String confirmacion2) {
        this.confirmacion2 = confirmacion2;
    }
    public String getConfirmacion2() {
        return confirmacion2;
    }

}
