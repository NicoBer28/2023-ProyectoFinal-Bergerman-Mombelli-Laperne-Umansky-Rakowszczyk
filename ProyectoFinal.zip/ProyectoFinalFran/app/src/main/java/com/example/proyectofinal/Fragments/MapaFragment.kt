package com.example.proyectofinal.Fragments

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import androidx.fragment.app.Fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.getSystemService
import com.example.proyectofinal.R

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MapaFragment : Fragment(), OnMapReadyCallback {

    private lateinit var auth: FirebaseAuth
    val db = Firebase.firestore
    private lateinit var googleMap: GoogleMap
    var latitudUser: Double = 10.0
    var longitudUser: Double = 10.0
    private val requestcode = 1


    private val callback = OnMapReadyCallback { googleMap ->

        val sydney = LatLng(-34.0, 151.0)
        googleMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_mapa, container, false)
        val btnUbiActual = view.findViewById<Button>(R.id.botonUbiActual)
        val userActual = FirebaseAuth.getInstance().currentUser
        val idUsuarioActual = userActual?.uid

        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)
        getLocation()

        btnUbiActual.setOnClickListener {
            googleMap.addMarker(
                MarkerOptions()
                    .position(LatLng(latitudUser, longitudUser))
                    .title("Marker")
                    .snippet("Population: 4,137,400")
            )

            val mapFragment = childFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
            mapFragment.getMapAsync { googleMap ->
                val cameraPosition = CameraPosition.Builder()
                    .target(LatLng(latitudUser, longitudUser))
                    .zoom(15f)
                    .build()
                googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))
            }

        }
        return view
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(this)
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
    }

    private fun getLocation() {

        var locationGps: Location? = null
        var locationNetwork: Location? = null

        val uid = Firebase.auth.currentUser?.uid
        locationManager =
            requireContext().getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val hasGps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val hasNetwork = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        //Pedir permiso de ubicacion

        if (ContextCompat.checkSelfPermission(
                requireActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                requireActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                requestcode
            )
        }

        if (hasGps || hasNetwork) {

            if (hasGps) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    5000,
                    0F,
                    object : LocationListener {
                        override fun onLocationChanged(p0: Location) {
                            if (p0 != null) {
                                locationGps = p0
                                if (uid != null) {
                                    Firebase.firestore.collection("users").document(uid).update(
                                        "Longitud",
                                        locationGps!!.longitude,
                                        "Latitud",
                                        locationGps!!.latitude
                                    )
                                        .addOnSuccessListener {
                                            flagFuncionUbicacion = 1

                                        }
                                        .addOnFailureListener {

                                        }
                                }
                            }
                        }

                    })

                val localGpsLocation =
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                if (localGpsLocation != null)
                    locationGps = localGpsLocation
            }
            if (hasNetwork) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    5000,
                    0F,
                    object : LocationListener {
                        override fun onLocationChanged(p0: Location) {
                            if (p0 != null) {
                                locationNetwork = p0
                                if (uid != null) {
                                    Firebase.firestore.collection("Users").document(uid)
                                        .update(
                                            "Longitud",
                                            locationNetwork!!.longitude,
                                            "Latitud",
                                            locationNetwork!!.latitude
                                        )
                                        .addOnSuccessListener {
                                            flagFuncionUbicacion = 1


                                        }
                                        .addOnFailureListener {

                                        }
                                }
                            }
                        }

                    })

                val localNetworkLocation =
                    locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                if (localNetworkLocation != null)
                    locationNetwork = localNetworkLocation
            }

            if (locationGps != null && locationNetwork != null) {
                if (locationGps!!.accuracy > locationNetwork!!.accuracy) {
                    if (uid != null) {
                        Firebase.firestore.collection("Users").document(uid).update(
                            "Longitud",
                            locationGps!!.longitude, "Latitud", locationGps!!.latitude
                        )
                            .addOnSuccessListener {
                                flagFuncionUbicacion = 1


                            }
                            .addOnFailureListener {

                            }
                    } else {
                        if (uid != null) {
                            Firebase.firestore.collection("Users").document(uid).update(
                                "Longitud",
                                locationNetwork!!.longitude, "Latitud", locationNetwork!!.latitude
                            )
                                .addOnSuccessListener {
                                    flagFuncionUbicacion = 1

                                }
                                .addOnFailureListener {
                                }
                        }
                    }

                }// else {
                //  startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                //}

            }

        }
        if (flagFuncionUbicacion == 0) {
            val snackbar =
                view?.let {
                    Snackbar.make(
                        it.findViewById(android.R.id.content),
                        "Failed location feed",
                        Snackbar.LENGTH_SHORT
                    )
                }
        } else {
            val snackbar =
                view?.let {
                    Snackbar.make(
                        it.findViewById(android.R.id.content),
                        "Location Data feeds start",
                        Snackbar.LENGTH_SHORT
                    )
                }
            if (snackbar != null) {
                snackbar.show()
            }
            latitudUser = locationGps!!.latitude
            longitudUser = locationGps!!.longitude
            /* googleMap.addMarker(
                 MarkerOptions()
                     .position(LatLng(locationGps!!.latitude, locationGps!!.longitude))
                     .title("Marker")
                     .snippet("Population: 4,137,400")
             )*//*
            val mapFragment = supportFragmentManager
                .findFragmentById(R.id.mapFragment) as SupportMapFragment
            mapFragment.getMapAsync { googleMap ->
                val cameraPosition = CameraPosition.Builder()
                    .target(LatLng(locationGps!!.latitude, locationGps!!.longitude))
                    .zoom(15f)
                    .build()
                googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))
            }
*/
        }
    }
}