package com.example.proyectofinal.Fragments

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.SearchView
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectofinal.R
import com.example.proyectofinal.ViewModelsFragments.myAdapter
import com.example.proyectofinal.ViewModelsFragments.myAdapterReservas
import com.example.proyectofinal.item
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.ArrayList

lateinit var botonPase: Button

class VendedorMisPedidos : Fragment() {

    companion object {
        fun newInstance() = VendedorMisPedidos()
    }

    private lateinit var viewModel: VendedorMisPedidosViewModel

    private val db = Firebase.firestore

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: myAdapterReservas
    private lateinit var itemArrayList: ArrayList<item>
    private lateinit var searchView: SearchView
    private var distancia: String = "ffgn"
    private var precio: String = "ffgn"
    private var horario: String = "ffgn"
    private var producto: String = "ffgn"
    private var idPubliVendedor: String = "ffgn"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_vendedor_mis_pedidos, container, false)
        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(VendedorMisPedidosViewModel::class.java)
        // TODO: Use the ViewModel
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        botonPase = view.findViewById<Button>(R.id.crearNueva)

        botonPase.setOnClickListener {

            findNavController().navigate(R.id.crearPublicaicon)
        }

        val idUsuarioActual = Firebase.auth.currentUser?.uid
        Log.e("VendedorMisPedidos", "aaaaa")

        // Initialize RecyclerView, LayoutManager, and Adapter
        recyclerView = view.findViewById(R.id.RecyclerVendedor)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Initialize your itemArrayList with data from Firebase or elsewhere
        itemArrayList = ArrayList()

        // Add your items to itemArrayList as needed
        // For example:
        db.collection("publicaciones")
            .get()
            .addOnSuccessListener { publis ->
                Log.e("VendedorMisPedidos", "entro")

//                itemArrayList.clear()

                for (publicaciones in publis) {

                    var newItem = item()
                    val precio = publicaciones.get("Precio") as String
                    val horario =
                        publicaciones.get("Horario De Retiro") as? String ?: "Retiro 20:00"
                    val producto = publicaciones.get("Producto") as String
                    val caducidad = publicaciones.get("Fecha Maxima Consumo") as String
                    val idPubliVendedor =
                        publicaciones.get("Id vendedor") as String
                    val reservado =
                        publicaciones.get("Reservado") as String
                    val confirmado =
                        publicaciones.get("Confirmado") as String

                    if(confirmado == "Si" && reservado == "Si"){
                        newItem.reserva3 = "Confirmado"
                    }

                    if(reservado == "Si" && confirmado == "No"){
                        newItem.reserva3 = "Reservado"
                    }

                    if(reservado == "No" && confirmado == "No"){
                        newItem.reserva3 = "No Reservado"
                    }

                    if (idPubliVendedor == idUsuarioActual){

                        newItem.precio3 = precio
                    newItem.horario3 = horario
                    newItem.producto3 = producto
                        newItem.id3 = idPubliVendedor

                    db.collection("vendedores")
                        .get()
                        .addOnSuccessListener { vendis ->
                            for (vendedores in vendis) {
                                val idVendedor = vendedores.id

                                if (idVendedor == idPubliVendedor) {

                                    val local = vendedores.get("Negocio") as String
                                    val direccion = vendedores.get("Direccion") as String
                                    // Create a new instance of item and set the "local" attribute
                                    newItem.local3 = local
                                    newItem.direccion3 = direccion

                                    db.collection("users")
                                        .get()
                                        .addOnSuccessListener { users ->
                                            for (usuarios in users) {
                                                val idUsuario = usuarios.id
                                                if (idUsuario == idUsuarioActual) {

                                                    val distanciasMap =
                                                        usuarios.get("Distancias") as Map<String, String>
                                                    for ((clave, valor) in distanciasMap) {
                                                        if (clave == idVendedor) {

                                                            distancia = valor

                                                            newItem.distancia3 = distancia

                                                            break // Terminar el bucle una vez que se encuentre la clave
                                                        }
                                                    }
                                                }
                                            }
                                            itemArrayList.add(newItem)

                                            // Create the adapter and set it on the RecyclerView
                                            adapter = myAdapterReservas(requireContext(), itemArrayList)
                                            recyclerView.adapter = adapter
                                        }
                                }
                            }
                        }



                            }





                }
            }
    }



}