package com.example.proyectofinal.ViewModelsFragments;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectofinal.R;
import com.example.proyectofinal.item;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class myAdapterReservasUsuarios extends RecyclerView.Adapter<myViewHolder> implements Filterable {
    String idPublicacion;
    Context context;
    List<item> items;
    List<item> filteredItems; // Lista para almacenar elementos filtrados
    private final Object lock = new Object();

    public myAdapterReservasUsuarios(Context context, List<item> items) {
        this.context = context;
        this.items = items;
        this.filteredItems = new ArrayList<>(items); // Inicializa la lista filtrada con la lista original
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new myViewHolder(LayoutInflater.from(context).inflate(R.layout.item_view_reservado, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
        item currentItem = filteredItems.get(position); // Obtén el elemento desde la lista filtrada
        holder.local2.setText(currentItem.getLocal());
        holder.direccion2.setText(currentItem.getDireccion());
        holder.distancia2.setText(currentItem.getDistancia());
        holder.horario2.setText(currentItem.getHorario());
        holder.precio2.setText(currentItem.getPrecio());
        holder.producto2.setText(currentItem.getProducto());
        holder.caducidad2.setText(currentItem.getCaducidad());
        holder.confirmacion2.setText(currentItem.getConfirmacion2());

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Agregar un OnClickListener al botón
        holder.itemView.findViewById(R.id.cancelar2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int itemPosition = holder.getAdapterPosition();
                if (itemPosition != RecyclerView.NO_POSITION) {
                    item selectedItem = filteredItems.get(itemPosition);

                    db.collection("publicaciones")
                            .get()
                            .addOnSuccessListener(queryDocumentSnapshots -> {
                                for (DocumentSnapshot publicacion : queryDocumentSnapshots) {
                                    String precio = publicacion.getString("Precio");
                                    String producto = publicacion.getString("Producto");
                                    String horario = publicacion.getString("Horario De Retiro");

                                    if (precio != null && producto != null && horario != null &&
                                            precio.equals(selectedItem.getPrecio()) &&
                                            producto.equals(selectedItem.getProducto()) &&
                                            horario.equals(selectedItem.getHorario())) {

                                        idPublicacion = publicacion.getId();
                                        // Hacer algo con idPublicacion
                                        System.out.println(idPublicacion);
                                        if (idPublicacion != null) {
                                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                                            DocumentReference userDocRef = db.collection("publicaciones").document(idPublicacion);

                                            // Crea un mapa para los datos del documento
                                            Map<String, Object> userData = new HashMap<>();
                                            userData.put("Reservado", "No");
                                            userData.put("Cliente", selectedItem.getId());

                                            userDocRef.update(userData)
                                                    .addOnSuccessListener(aVoid -> {
                                                        // El campo "Reservado" se ha actualizado correctamente
                                                    })
                                                    .addOnFailureListener(e -> {
                                                        System.out.println("no funciono");
                                                    });
                                        } else {
                                            System.out.println("errorrr");
                                        }
                                    }
                                }
                            });
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return filteredItems.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String filterPattern = constraint.toString().toLowerCase().trim();
                FilterResults results = new FilterResults();

                synchronized (lock) {
                    List<item> filteredList = new ArrayList<>();
                    if (filterPattern.isEmpty()) {
                        filteredList.addAll(items); // Si no hay filtro, muestra todos los elementos originales
                    } else {
                        for (item item : items) {
                            // Filtra los elementos basados en el patrón de búsqueda
                            if (item.getLocal().toLowerCase().contains(filterPattern)) {
                                filteredList.add(item);
                            }
                        }
                    }
                    results.values = filteredList;
                    results.count = filteredList.size();
                }

                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredItems.clear();
                filteredItems.addAll((List<item>) results.values);
                notifyDataSetChanged(); // Notifica al RecyclerView para que se actualice con los elementos filtrados
            }
        };
    }
}
