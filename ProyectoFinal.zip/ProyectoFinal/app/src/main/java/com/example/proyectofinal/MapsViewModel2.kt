package com.example.proyectofinal

import androidx.lifecycle.ViewModel

class MapsViewModel2 : ViewModel() {
    // TODO: Implement the ViewModel
}