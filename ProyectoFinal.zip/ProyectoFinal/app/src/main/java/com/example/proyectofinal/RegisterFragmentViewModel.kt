package com.example.proyectofinal

import androidx.lifecycle.ViewModel

class RegisterFragmentViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}