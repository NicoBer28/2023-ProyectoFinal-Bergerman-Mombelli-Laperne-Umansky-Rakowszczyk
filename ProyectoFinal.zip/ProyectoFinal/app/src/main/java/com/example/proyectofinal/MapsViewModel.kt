package com.example.proyectofinal

import androidx.lifecycle.ViewModel

class MapsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}