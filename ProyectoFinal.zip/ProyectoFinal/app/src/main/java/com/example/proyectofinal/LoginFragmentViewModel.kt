package com.example.proyectofinal

import androidx.lifecycle.ViewModel

class LoginFragmentViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}