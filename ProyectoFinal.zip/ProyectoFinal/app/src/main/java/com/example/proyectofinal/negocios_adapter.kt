package com.example.proyectofinal

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar

class RecyclerAdapter : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {
    private val kode = arrayOf("Mcdonalds",
        "Burguer King", "Subway", "Panaderia",
        "Mcdonalds", "Mcdonalds", "Mcdonalds",
        "Wendys")

    private val kategori = arrayOf("1253", "Teknologi",
        "Keluarga", "Bisnis",
        "Keluarga", "Hutang",
        "Teknologi", "Pidana")

    private val isi = arrayOf("Corrientes 1250",
        "Las Heras 3200", "Rio de janeiro 4100", "Yapeyu 164",
        "Corrientes 1250", "Corrientes 1250", "Corrientes 1250",
        "Cordoba 620")

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var itemKode: TextView
        var itemKategori: TextView
        var itemIsi: TextView

        init {
            itemKode = itemView.findViewById(R.id.nombreNegocio)
            itemKategori = itemView.findViewById(R.id.categoriaNegocio)
            itemIsi = itemView.findViewById(R.id.direccionNegocio)

            itemView.setOnClickListener {
                val snackbar =
                    Snackbar.make(it, itemKode.text, Snackbar.LENGTH_SHORT)
                snackbar.show()
              /*  var position: Int = getAdapterPosition()
                val context = itemView.context
                val intent = Intent(context, mapsActivity::class.java).apply {
                   /* putExtra("NUMBER", position)
                    putExtra("CODE", itemKode.text)
                    putExtra("CATEGORY", itemKategori.text)
                    putExtra("CONTENT", itemIsi.text)*/
                }
                context.startActivity(intent)*/
            }
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        val v = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.negocios_cardview, viewGroup, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        viewHolder.itemKode.text = kode[i]
        viewHolder.itemKategori.text = kategori[i]
        viewHolder.itemIsi.text = isi[i]

    }

    override fun getItemCount(): Int {
        return kode.size
    }

}