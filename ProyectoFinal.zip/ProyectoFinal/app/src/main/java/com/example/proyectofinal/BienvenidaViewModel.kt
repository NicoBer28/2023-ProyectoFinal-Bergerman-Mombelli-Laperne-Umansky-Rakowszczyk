package com.example.proyectofinal

import androidx.lifecycle.ViewModel

class BienvenidaViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}