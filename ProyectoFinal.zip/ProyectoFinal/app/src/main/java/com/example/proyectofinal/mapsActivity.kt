package com.example.proyectofinal

import android.Manifest
import android.app.PendingIntent.getActivity
import android.content.ContentValues.TAG
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class mapsActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var auth: FirebaseAuth
    val db = Firebase.firestore
    private lateinit var googleMap: GoogleMap
    var latitudUser: Double = 10.0
    var longitudUser: Double = 10.0
    private val requestcode = 1


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        val btnUbiActual = findViewById<Button>(R.id.btnUbiActual)
        val userActual = FirebaseAuth.getInstance().currentUser
        val idUsuarioActual = userActual?.uid

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)
        getLocation()

        btnUbiActual.setOnClickListener {
            googleMap.addMarker(
                MarkerOptions()
                    .position(LatLng(latitudUser, longitudUser))
                    .title("Marker")
                    .snippet("Population: 4,137,400")
            )

            val mapFragment = supportFragmentManager
                .findFragmentById(R.id.mapFragment) as SupportMapFragment
            mapFragment.getMapAsync { googleMap ->
                val cameraPosition = CameraPosition.Builder()
                    .target(LatLng(latitudUser, longitudUser))
                    .zoom(15f)
                    .build()
                googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))
            }

        }

        //Toast.makeText(this, latitudUser.toString(), Toast.LENGTH_SHORT).show();

    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
    }

    private fun getLocation() {

        var locationGps: Location? = null
        var locationNetwork: Location? = null

        val uid = Firebase.auth.currentUser?.uid
        locationManager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val hasGps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val hasNetwork = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        //Pedir permiso de ubicacion

        if (checkSelfPermission(
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                requestcode
            )
        }

        if (hasGps || hasNetwork) {

            if (hasGps) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    5000,
                    0F,
                    object : LocationListener {
                        override fun onLocationChanged(p0: Location) {
                            if (p0 != null) {
                                locationGps = p0
                                if (uid != null) {
                                    Firebase.firestore.collection("users").document(uid).update(
                                        "Longitud",
                                        locationGps!!.longitude,
                                        "Latitud",
                                        locationGps!!.latitude
                                    )
                                        .addOnSuccessListener {
                                            flagFuncionUbicacion = 1

                                        }
                                        .addOnFailureListener {

                                        }
                                }
                            }
                        }

                    })

                val localGpsLocation =
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                if (localGpsLocation != null)
                    locationGps = localGpsLocation
            }
            if (hasNetwork) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    5000,
                    0F,
                    object : LocationListener {
                        override fun onLocationChanged(p0: Location) {
                            if (p0 != null) {
                                locationNetwork = p0
                                if (uid != null) {
                                    Firebase.firestore.collection("Users").document(uid)
                                        .update(
                                            "Longitud",
                                            locationNetwork!!.longitude,
                                            "Latitud",
                                            locationNetwork!!.latitude
                                        )
                                        .addOnSuccessListener {
                                            flagFuncionUbicacion = 1


                                        }
                                        .addOnFailureListener {

                                        }
                                }
                            }
                        }

                    })

                val localNetworkLocation =
                    locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                if (localNetworkLocation != null)
                    locationNetwork = localNetworkLocation
            }

            if (locationGps != null && locationNetwork != null) {
                if (locationGps!!.accuracy > locationNetwork!!.accuracy) {
                    if (uid != null) {
                        Firebase.firestore.collection("Users").document(uid).update(
                            "Longitud",
                            locationGps!!.longitude, "Latitud", locationGps!!.latitude
                        )
                            .addOnSuccessListener {
                                flagFuncionUbicacion = 1


                            }
                            .addOnFailureListener {

                            }
                    } else {
                        if (uid != null) {
                            Firebase.firestore.collection("Users").document(uid).update(
                                "Longitud",
                                locationNetwork!!.longitude, "Latitud", locationNetwork!!.latitude
                            )
                                .addOnSuccessListener {
                                    flagFuncionUbicacion = 1

                                }
                                .addOnFailureListener {
                                }
                        }
                    }

                }// else {
                //  startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                //}

            }

        }
        if (flagFuncionUbicacion == 0) {
            val snackbar =
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Failed location feed",
                    Snackbar.LENGTH_SHORT
                )
        } else {
            val snackbar =
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Location Data feeds start",
                    Snackbar.LENGTH_SHORT
                )
            snackbar.show()
            latitudUser = locationGps!!.latitude
            longitudUser = locationGps!!.longitude
           /* googleMap.addMarker(
                MarkerOptions()
                    .position(LatLng(locationGps!!.latitude, locationGps!!.longitude))
                    .title("Marker")
                    .snippet("Population: 4,137,400")
            )*//*
            val mapFragment = supportFragmentManager
                .findFragmentById(R.id.mapFragment) as SupportMapFragment
            mapFragment.getMapAsync { googleMap ->
                val cameraPosition = CameraPosition.Builder()
                    .target(LatLng(locationGps!!.latitude, locationGps!!.longitude))
                    .zoom(15f)
                    .build()
                googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))
            }
*/
        }
    }
}
