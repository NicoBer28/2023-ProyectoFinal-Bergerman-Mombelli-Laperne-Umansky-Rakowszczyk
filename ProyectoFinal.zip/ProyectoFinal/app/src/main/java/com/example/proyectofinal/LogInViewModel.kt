package com.example.proyectofinal

import androidx.lifecycle.ViewModel

class LogInViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}