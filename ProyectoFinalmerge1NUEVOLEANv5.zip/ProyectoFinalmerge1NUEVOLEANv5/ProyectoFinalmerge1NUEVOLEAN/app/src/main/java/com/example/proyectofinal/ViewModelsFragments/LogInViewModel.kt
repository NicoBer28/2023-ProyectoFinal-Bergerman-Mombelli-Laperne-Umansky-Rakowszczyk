package com.example.proyectofinal.ViewModelsFragments

import androidx.lifecycle.ViewModel

class LogInViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}