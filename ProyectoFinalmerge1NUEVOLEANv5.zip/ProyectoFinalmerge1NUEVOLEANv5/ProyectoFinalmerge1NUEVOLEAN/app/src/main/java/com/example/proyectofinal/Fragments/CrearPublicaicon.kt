package com.example.proyectofinal.Fragments

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.navigation.fragment.findNavController
import com.example.proyectofinal.R
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*

lateinit var btnPublicar: Button

lateinit var vendedorHorarioRetiro: EditText
lateinit var vendedorPrecio : EditText
lateinit var vendedorProducto: EditText
lateinit var vendedorFechaMaximaConsumo: EditText

lateinit var vendedorHorarioRetiroIngresada : String
lateinit var vendedorPrecioIngresado : String
lateinit var vendedorProductoIngresado : String
lateinit var vendedorFechaMaximaConsumoIngresado : String

lateinit var botonVolver: Button

var campoVacio : Int = 0

class CrearPublicaicon : Fragment() {

    companion object {
        fun newInstance() = CrearPublicaicon()
    }

    private lateinit var viewModel: CrearPublicaiconViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_crear_publicaicon, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(CrearPublicaiconViewModel::class.java)
        // TODO: Use the ViewModel
    }

    private lateinit var auth: FirebaseAuth

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val db = Firebase.firestore

        auth = Firebase.auth

        val idUsuarioActual = Firebase.auth.currentUser?.uid
        Log.d("MiApp", "Valor de idUsuarioActual: $idUsuarioActual")

        btnPublicar = view.findViewById<Button>(R.id.btnPublicar)

        botonVolver = view.findViewById<Button>(R.id.button8)

        vendedorHorarioRetiro = view.findViewById<EditText>(R.id.direccionV)
        vendedorPrecio = view.findViewById<EditText>(R.id.passwordCreateV)
        vendedorProducto = view.findViewById<EditText>(R.id.passwordConfirmV)
        vendedorFechaMaximaConsumo = view.findViewById<EditText>(R.id.fechaMaxima)

        botonVolver.setOnClickListener {

            findNavController().navigate(R.id.vendedorMisPedidos)
        }

        btnPublicar.setOnClickListener {
            vendedorHorarioRetiroIngresada = vendedorHorarioRetiro.text.toString()
            vendedorPrecioIngresado = vendedorPrecio.text.toString()
            vendedorProductoIngresado = vendedorProducto.text.toString()
            vendedorFechaMaximaConsumoIngresado = vendedorFechaMaximaConsumo.text.toString()

            var usuarios: MutableList<String> = mutableListOf(
                vendedorHorarioRetiroIngresada,
                vendedorPrecioIngresado,
                vendedorProductoIngresado,
                vendedorFechaMaximaConsumoIngresado
            )
            campoVacio = 0

            for (campos in usuarios) {
                if (campos == "") {
                    campoVacio = 1
                    val snackbar =
                        Snackbar.make(it, "Complete todos los campos", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                }
            }

            if (campoVacio == 0) {
                val snackbar =
                    Snackbar.make(it, "Publicacion Creada", Snackbar.LENGTH_SHORT)
                snackbar.show()

                val userActual = FirebaseAuth.getInstance().currentUser

                // Genera un ID único y aleatorio
                val nuevoID = UUID.randomUUID().toString()

                // Crea una referencia al documento con el nuevo ID en la colección "publicaciones"
                val userDocRef = db.collection("publicaciones").document(nuevoID)

                // Set the data for the user document
                val userData = hashMapOf(
                    "Id vendedor" to idUsuarioActual,
                    "Horario De Retiro" to vendedorHorarioRetiroIngresada,
                    "Precio" to vendedorPrecioIngresado,
                    "Producto" to vendedorProductoIngresado,
                    "Fecha Maxima Consumo" to vendedorFechaMaximaConsumoIngresado
                )

                userDocRef.set(userData).addOnSuccessListener {

                }.addOnFailureListener { e ->
                    val snackbar = Snackbar.make(it, "Error subiendo la publicacion", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                }

            }
        }
    }

}