package com.example.proyectofinal.Fragments

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.fragment.findNavController
import com.example.proyectofinal.R

lateinit var botonPase: Button

class VendedorMisPedidos : Fragment() {

    companion object {
        fun newInstance() = VendedorMisPedidos()
    }

    private lateinit var viewModel: VendedorMisPedidosViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_vendedor_mis_pedidos, container, false)
        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(VendedorMisPedidosViewModel::class.java)
        // TODO: Use the ViewModel
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        botonPase = view.findViewById<Button>(R.id.button7)

        botonPase.setOnClickListener {

            findNavController().navigate(R.id.crearPublicaicon)
        }
    }

}