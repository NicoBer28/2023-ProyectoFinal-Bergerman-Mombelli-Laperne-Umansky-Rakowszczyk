package com.example.proyectofinal.ViewModelsFragments;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectofinal.R;

public class myViewHolder extends RecyclerView.ViewHolder {

    TextView local, direccion, distancia, horario, precio, producto, confirmacion,
            local3, direccion3, distancia3, horario3, precio3, producto3, caducidad, reserva3,
            local2, direccion2, distancia2, horario2, precio2, producto2, caducidad2;

    public myViewHolder(@NonNull View itemView) {

        super(itemView);
        //publicaciones(usuarios)
        local = itemView.findViewById(R.id.nombre);
        direccion = itemView.findViewById(R.id.direccion);
        distancia = itemView.findViewById(R.id.distancia);
        horario = itemView.findViewById(R.id.horario);
        precio = itemView.findViewById(R.id.precio);
        producto = itemView.findViewById(R.id.producto);
        caducidad = itemView.findViewById(R.id.caducidad);

        //reservas(usuarios)
        local2 = itemView.findViewById(R.id.nombre2);
        direccion2 = itemView.findViewById(R.id.direccion2);
        distancia2 = itemView.findViewById(R.id.distancia2);
        horario2 = itemView.findViewById(R.id.horario2);
        precio2 = itemView.findViewById(R.id.precio2);
        producto2 = itemView.findViewById(R.id.producto2);
        caducidad2 = itemView.findViewById(R.id.caducidad2);

        //publicaciones(vendedores)
        local3 = itemView.findViewById(R.id.nombre3);
        direccion3 = itemView.findViewById(R.id.direccion3);
        distancia3 = itemView.findViewById(R.id.distancia3);
        horario3 = itemView.findViewById(R.id.horario3);
        precio3 = itemView.findViewById(R.id.precio3);
        producto3 = itemView.findViewById(R.id.producto3);
        reserva3 = itemView.findViewById(R.id.reserva3);

    }
}
