package com.example.proyectofinal

import androidx.lifecycle.ViewModel

class VendedoresRegistrarViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}