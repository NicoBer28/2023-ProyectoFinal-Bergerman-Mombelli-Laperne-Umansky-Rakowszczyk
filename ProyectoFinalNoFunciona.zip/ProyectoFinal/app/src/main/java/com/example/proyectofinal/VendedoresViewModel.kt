package com.example.proyectofinal

import androidx.lifecycle.ViewModel

class VendedoresViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}