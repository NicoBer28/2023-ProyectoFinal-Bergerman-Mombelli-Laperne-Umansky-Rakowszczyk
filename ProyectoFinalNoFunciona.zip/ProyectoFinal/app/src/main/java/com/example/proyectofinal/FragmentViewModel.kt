package com.example.proyectofinal

import androidx.lifecycle.ViewModel

class FragmentViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}