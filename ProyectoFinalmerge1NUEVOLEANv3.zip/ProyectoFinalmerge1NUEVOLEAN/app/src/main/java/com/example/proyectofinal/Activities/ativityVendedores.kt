package com.example.proyectofinal.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.example.proyectofinal.Fragments.*
import com.example.proyectofinal.R
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

lateinit var btnPublicar: Button

lateinit var vendedorNegocio: EditText
lateinit var vendedorDireccion: EditText
lateinit var vendedorHorarioRetiro: EditText
lateinit var vendedorPrecio : EditText
lateinit var vendedorProducto: EditText
lateinit var vendedorFechaMaximaConsumo: EditText

lateinit var vendedorNegocioIngresado : String
lateinit var vendedorDireccionIngresada : String
lateinit var vendedorHorarioRetiroIngresada : String
lateinit var vendedorPrecioIngresado : String
lateinit var vendedorProductoIngresado : String
lateinit var vendedorFechaMaximaConsumoIngresado : String

var camposVacios: Int = 0

class ativityVendedores : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Firebase.firestore

        auth = Firebase.auth

        val idUsuarioActual = Firebase.auth.currentUser?.uid

        btnPublicar = findViewById<Button>(R.id.btnPublicar)

        vendedorNegocio = findViewById<EditText>(R.id.negocioV)
        vendedorDireccion = findViewById<EditText>(R.id.emailV)
        vendedorHorarioRetiro = findViewById<EditText>(R.id.direccionV)
        vendedorPrecio = findViewById<EditText>(R.id.passwordCreateV)
        vendedorProducto = findViewById<EditText>(R.id.passwordConfirmV)
        vendedorFechaMaximaConsumo = findViewById<EditText>(R.id.fechaMaxima)

        btnConfirmRegister.setOnClickListener {
            vendedorNegocioIngresado = vendedorNegocio.text.toString()
            vendedorDireccionIngresada = vendedorDireccion.text.toString()
            vendedorHorarioRetiroIngresada = vendedorHorarioRetiro.text.toString()
            vendedorPrecioIngresado = vendedorPrecio.text.toString()
            vendedorProductoIngresado = vendedorProducto.text.toString()
            vendedorFechaMaximaConsumoIngresado = vendedorFechaMaximaConsumo.text.toString()

            var usuarios: MutableList<String> = mutableListOf(
                vendedorNegocioIngresado,
                vendedorDireccionIngresada,
                vendedorHorarioRetiroIngresada,
                vendedorPrecioIngresado,
                vendedorProductoIngresado,
                vendedorFechaMaximaConsumoIngresado
            )

            for (campos in usuarios) {
                if (campos == "") {
                    camposVacios = 1
                }
            }

            if (camposVacios == 0) {

                auth.createUserWithEmailAndPassword(vendedorEmailIngresado, vendedorContraIngresada)
                    .addOnCompleteListener() { task ->
                        if (task.isSuccessful) {
                            // Get the currently authenticated user
                            val userActual = FirebaseAuth.getInstance().currentUser

                            // Create a new user document with the user's ID as the document ID
                            val userDocRef = userActual?.let { it1 ->
                                db.collection("vendedores").document(
                                    it1.uid
                                )
                            }

                            // Set the data for the user document
                            val userData = hashMapOf(
                                "Negocio" to vendedorNegocioIngresado,
                                "Email" to vendedorEmailIngresado,
                                "Direccion" to vendedorDireccionIngresada,
                                "Contraseña" to vendedorContraIngresada
                            )

                            userDocRef?.set(userData)?.addOnSuccessListener {

                            }?.addOnFailureListener { e ->
                                val snackbar =
                                    Snackbar.make(it, "Publicacion creada", Snackbar.LENGTH_SHORT)
                                snackbar.show()
                            }
                        }
                    }
            }
        }
    }
}