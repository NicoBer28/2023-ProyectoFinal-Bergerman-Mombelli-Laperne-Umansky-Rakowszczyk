package com.example.proyectofinal.ViewModelsFragments;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectofinal.R;
import com.example.proyectofinal.item;

import java.util.ArrayList;
import java.util.List;

public class myAdapter extends RecyclerView.Adapter<myViewHolder> implements Filterable {

    Context context;
    List<item> items;
    List<item> filteredItems; // Lista para almacenar elementos filtrados
    private final Object lock = new Object();

    public myAdapter(Context context, List<item> items) {
        this.context = context;
        this.items = items;
        this.filteredItems = new ArrayList<>(items); // Inicializa la lista filtrada con la lista original
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new myViewHolder(LayoutInflater.from(context).inflate(R.layout.item_view, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
        item currentItem = filteredItems.get(position); // Obtén el elemento desde la lista filtrada
        holder.local.setText(currentItem.getLocal());
        holder.direccion.setText(currentItem.getDireccion());
        holder.distancia.setText(currentItem.getDistancia());
        holder.horario.setText(currentItem.getHorario());
        holder.precio.setText(currentItem.getPrecio());
        holder.producto.setText(currentItem.getProducto());
    }

    @Override
    public int getItemCount() {
        return filteredItems.size(); // Usa el tamaño de la lista filtrada
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String filterPattern = constraint.toString().toLowerCase().trim();
                FilterResults results = new FilterResults();

                synchronized (lock) {
                    List<item> filteredList = new ArrayList<>();
                    if (filterPattern.isEmpty()) {
                        filteredList.addAll(items); // Si no hay filtro, muestra todos los elementos originales
                    } else {
                        for (item item : items) {
                            // Filtra los elementos basados en el patrón de búsqueda
                            if (item.getLocal().toLowerCase().contains(filterPattern)) {
                                filteredList.add(item);
                            }
                        }
                    }
                    results.values = filteredList;
                    results.count = filteredList.size();
                }

                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredItems.clear();
                filteredItems.addAll((List<item>) results.values);
                notifyDataSetChanged(); // Notifica al RecyclerView para que se actualice con los elementos filtrados
            }
        };

    }
}

