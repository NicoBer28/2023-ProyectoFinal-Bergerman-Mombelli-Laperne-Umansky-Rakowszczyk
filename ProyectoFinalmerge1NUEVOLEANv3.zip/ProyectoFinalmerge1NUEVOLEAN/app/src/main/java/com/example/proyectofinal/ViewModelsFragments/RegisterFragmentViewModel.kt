package com.example.proyectofinal.ViewModelsFragments

import androidx.lifecycle.ViewModel

class RegisterFragmentViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}