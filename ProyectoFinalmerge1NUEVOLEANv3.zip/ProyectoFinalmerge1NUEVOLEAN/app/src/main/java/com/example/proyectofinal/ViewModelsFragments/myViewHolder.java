package com.example.proyectofinal.ViewModelsFragments;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectofinal.R;

public class myViewHolder extends RecyclerView.ViewHolder {

    TextView local, direccion, distancia, horario, precio, producto;

    public myViewHolder(@NonNull View itemView) {

        super(itemView);
        local = itemView.findViewById(R.id.nombre);
        direccion = itemView.findViewById(R.id.direccion);
        distancia = itemView.findViewById(R.id.distancia);
        horario = itemView.findViewById(R.id.horario);
        precio = itemView.findViewById(R.id.precio);
        producto = itemView.findViewById(R.id.producto);

    }
}
