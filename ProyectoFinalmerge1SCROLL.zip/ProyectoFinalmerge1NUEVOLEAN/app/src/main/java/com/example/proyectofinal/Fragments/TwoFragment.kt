package com.example.proyectofinal.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectofinal.R
import com.example.proyectofinal.ViewModelsFragments.myAdapter
import com.example.proyectofinal.item
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*

class TwoFragment : Fragment() {
    private val db = Firebase.firestore

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: myAdapter
    private lateinit var itemArrayList: ArrayList<item>
    private lateinit var searchView: SearchView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_two, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize RecyclerView, LayoutManager, and Adapter
        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Initialize your itemArrayList with data from Firebase or elsewhere
        itemArrayList = ArrayList()

        // Add your items to itemArrayList as needed
        // For example:
        db.collection("vendedores")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    val local = document.get("Negocio") as String
                    // Create a new instance of item and set the "local" attribute
                    var newItem = item()
                    newItem.setLocal(local)

                    val direccion = document.get("Direccion") as String
                    // Create a new instance of item and set the "local" attribute
                    newItem.setDireccion(direccion)

                    itemArrayList.add(newItem)
                }

                // Create the adapter and set it on the RecyclerView
                adapter = myAdapter(requireContext(), itemArrayList)
                recyclerView.adapter = adapter

                // Initialize SearchView
                searchView = view.findViewById(R.id.idSV)
                searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                    override fun onQueryTextSubmit(query: String?): Boolean {
                        // Handle query submission if needed
                        return false
                    }

                    override fun onQueryTextChange(newText: String?): Boolean {
                        // Filter the adapter when text changes
                        adapter.filter.filter(newText)
                        return true
                    }
                })
            }
    }
}