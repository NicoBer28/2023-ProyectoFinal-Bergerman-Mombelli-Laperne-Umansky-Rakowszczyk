package com.example.proyectofinal.ViewModelsFragments;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavHostController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectofinal.Fragments.ThreeFragment;
import com.example.proyectofinal.Fragments.TwoFragment;
import com.example.proyectofinal.R;

import com.example.proyectofinal.item;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kotlin.Unit;
//ESTE ES EL ADAPTER PARA ITEM_VIEW_VENDEDORES. ES PARA LOS VENDEDORES
public class myAdapterReservas extends RecyclerView.Adapter<myViewHolder> implements Filterable {
    String idPublicacion;
    Context context;
    List<item> items;
    List<item> filteredItems; // Lista para almacenar elementos filtrados
    private final Object lock = new Object();

    public myAdapterReservas(Context context, List<item> items) {
        this.context = context;
        this.items = items;
        this.filteredItems = new ArrayList<>(items); // Inicializa la lista filtrada con la lista original
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new myViewHolder(LayoutInflater.from(context).inflate(R.layout.item_view_vendedores, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
        item currentItem = filteredItems.get(position); // Obtén el elemento desde la lista filtrada
        holder.local3.setText(currentItem.getLocal3());
        holder.direccion3.setText(currentItem.getDireccion3());
        holder.distancia3.setText(currentItem.getDistancia3());
        holder.horario3.setText(currentItem.getHorario3());
        holder.precio3.setText(currentItem.getPrecio3());
        holder.producto3.setText(currentItem.getProducto3());

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Agregar un OnClickListener al botón
        holder.itemView.findViewById(R.id.cnfirmar3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int itemPosition = holder.getAdapterPosition();
                if (itemPosition != RecyclerView.NO_POSITION) {
                    item selectedItem = filteredItems.get(itemPosition);
                    // Realiza acciones basadas en el botón pulsado y los datos de la tarjeta
                    // Por ejemplo, imprimir el producto de la tarjeta
                    db.collection("publicaciones")
                            .get()
                            .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                @Override
                                public void onSuccess(QuerySnapshot publicaciones) {
                                    for (QueryDocumentSnapshot publicacion : publicaciones) {
                                        String precio = publicacion.getString("Precio");
                                        String producto = publicacion.getString("Producto");
                                        String horario = publicacion.getString("Horario De Retiro");


                                        if (precio != null && producto != null && horario != null &&
                                                precio.equals(selectedItem.getPrecio3()) &&
                                                producto.equals(selectedItem.getProducto3()) &&
                                                horario.equals(selectedItem.getHorario3())) {

                                            idPublicacion = publicacion.getId();
                                            // Hacer algo con idPublicacion
                                            System.out.println(idPublicacion);
                                            if (idPublicacion != null) {

                                                DocumentReference userDocRef = db.collection("publicaciones").document(idPublicacion);

                                                // Crea un mapa para los datos del documento
                                                Map<String, Object> userData = new HashMap<>();
                                                userData.put("Reservado", "Si");

                                                userDocRef.update(userData)
                                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                            @Override
                                                            public void onSuccess(Void aVoid) {
                                                                // El campo "Reservado" se ha actualizado correctamente
                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                System.out.println("no funciono");
                                                            }
                                                        });
                                            }else{
                                                System.out.println("errorrr");

                                            }

                                        }
                                    }
                                }
                            });


                }


            }

            public int getItemCount() {
                return filteredItems.size(); // Usa el tamaño de la lista filtrada
            }

            public Filter getFilter() {
                return new Filter() {
                    @Override
                    protected FilterResults performFiltering(CharSequence constraint) {
                        String filterPattern = constraint.toString().toLowerCase().trim();
                        FilterResults results = new FilterResults();

                        synchronized (lock) {
                            List<item> filteredList = new ArrayList<>();
                            if (filterPattern.isEmpty()) {
                                filteredList.addAll(items); // Si no hay filtro, muestra todos los elementos originales
                            } else {
                                for (item item : items) {
                                    // Filtra los elementos basados en el patrón de búsqueda
                                    if (item.getLocal().toLowerCase().contains(filterPattern)) {
                                        filteredList.add(item);
                                    }
                                }
                            }
                            results.values = filteredList;
                            results.count = filteredList.size();
                        }

                        return results;
                    }

                    @Override
                    protected void publishResults(CharSequence constraint, FilterResults results) {
                        filteredItems.clear();
                        filteredItems.addAll((List<item>) results.values);
                        notifyDataSetChanged(); // Notifica al RecyclerView para que se actualice con los elementos filtrados
                    }
                };

            }
        });



        // Agregar un OnClickListener al botón
        holder.itemView.findViewById(R.id.editar3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int itemPosition = holder.getAdapterPosition();
                if (itemPosition != RecyclerView.NO_POSITION) {
                    item selectedItem = filteredItems.get(itemPosition);
                    // Realiza acciones basadas en el botón pulsado y los datos de la tarjeta
                    // Por ejemplo, imprimir el producto de la tarjeta
                    db.collection("publicaciones")
                            .get()
                            .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                @Override
                                public void onSuccess(QuerySnapshot publicaciones) {
                                    for (QueryDocumentSnapshot publicacion : publicaciones) {
                                        String precio = publicacion.getString("Precio");
                                        String producto = publicacion.getString("Producto");
                                        String horario = publicacion.getString("Horario De Retiro");


                                        if (precio != null && producto != null && horario != null &&
                                                precio.equals(selectedItem.getPrecio3()) &&
                                                producto.equals(selectedItem.getProducto3()) &&
                                                horario.equals(selectedItem.getHorario3())) {

                                            idPublicacion = publicacion.getId();
                                            // Hacer algo con idPublicacion
                                            System.out.println(idPublicacion);
                                            if (idPublicacion != null) {

                                                DocumentReference userDocRef = db.collection("publicaciones").document(idPublicacion);

                                                // Crea un mapa para los datos del documento
                                                Map<String, Object> userData = new HashMap<>();
                                                userData.put("Editando", "Si");

                                                userDocRef.update(userData)
                                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                            @Override
                                                            public void onSuccess(Void aVoid) {
                                                                // cambiar de fragment acá
                                                                NavController navController = Navigation.findNavController(v);
                                                                navController.navigate(R.id.crearPublicaicon);
                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                System.out.println("no funciono");
                                                            }
                                                        });
                                            }else{
                                                System.out.println("errorrr");

                                            }

                                        }
                                    }
                                }
                            });


                }


            }

            public int getItemCount() {
                return filteredItems.size(); // Usa el tamaño de la lista filtrada
            }

            public Filter getFilter() {
                return new Filter() {
                    @Override
                    protected FilterResults performFiltering(CharSequence constraint) {
                        String filterPattern = constraint.toString().toLowerCase().trim();
                        FilterResults results = new FilterResults();

                        synchronized (lock) {
                            List<item> filteredList = new ArrayList<>();
                            if (filterPattern.isEmpty()) {
                                filteredList.addAll(items); // Si no hay filtro, muestra todos los elementos originales
                            } else {
                                for (item item : items) {
                                    // Filtra los elementos basados en el patrón de búsqueda
                                    if (item.getLocal().toLowerCase().contains(filterPattern)) {
                                        filteredList.add(item);
                                    }
                                }
                            }
                            results.values = filteredList;
                            results.count = filteredList.size();
                        }

                        return results;
                    }

                    @Override
                    protected void publishResults(CharSequence constraint, FilterResults results) {
                        filteredItems.clear();
                        filteredItems.addAll((List<item>) results.values);
                        notifyDataSetChanged(); // Notifica al RecyclerView para que se actualice con los elementos filtrados
                    }
                };

            }
        });






    }
    ;


    @Override
    public int getItemCount() {
        return filteredItems.size();
    }

    @Override
    public Filter getFilter() {
        // ... (resto del código de filtrado)
        return null;
    }
}

