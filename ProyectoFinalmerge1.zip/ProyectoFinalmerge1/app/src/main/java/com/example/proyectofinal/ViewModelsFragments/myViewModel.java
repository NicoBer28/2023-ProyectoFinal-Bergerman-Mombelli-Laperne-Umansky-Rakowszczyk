package com.example.proyectofinal.ViewModelsFragments;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class myViewHolder extends RecyclerView.ViewHolder {

    ImageView imageView;
    TextView nombre, email;

    public myViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
